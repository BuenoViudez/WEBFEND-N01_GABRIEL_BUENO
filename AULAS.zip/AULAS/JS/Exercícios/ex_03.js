let nota1 = 10
let nota2 = 7
let nota3 = 5
let nota4 = 9
let nota5 = 4
let soma = nota1 + nota2 + nota3 + nota4 + nota5 

console.log(soma)

console.log(`A média das notas é a soma das 5 notas ${soma} dividido por 5 é ${(soma)/5}`)




