let gol1 = 7;
let gol2 = 2;
let gol3 = 40;

if (gol1 > gol2 && gol1 > gol3) {
    console.log(`O artilheiro do brasileirão foi o Calleri do São Paulo com ${gol1} gols na temporada`);
}
else if (gol3 > gol1 && gol3 > gol2) {
    console.log(`Dudu ficou na vice artilharia com ${gol3} gols marcado`);
}

else {
    console.log(`Manoel Gomes ficou na lanterna da artilharia com ${gol2} gols marcado`);
}


