let num = 0;
for(let i = 0; i <= 100; i++) {

    if (i % 2 === 0) {
        num += i
    }
 }
 console.log(`\nO valor da soma de todos os numeros pares até 100 é de: ${num}`);












// Calcular a soma dos números pares de 1 a 100