let num1 = 100
let num2 = 2 
let metade = num1 / num2

console.log(metade)

console.log(`A divisão de ${num1} por ${num2} é igual a ${metade} `)