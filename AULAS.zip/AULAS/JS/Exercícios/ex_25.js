let idade = 15;

if (idade >= 16) {
    console.log(`Voce tem ${idade} anos, então pode votar`);
}
else {
    console.log(`Voce tem ${idade} anos, entao nao pode votar`);
 }