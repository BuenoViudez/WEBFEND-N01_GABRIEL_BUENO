let num3 = 0;

while (num3 <= 20){
    if (num3 % 2 == 0){
        console.log(`${num3} É PAR`);
    }  
    
    num3++;
}

console.log("THE END !!!");