let num1 = 0;

while (num1 <= 10) {
    console.log(num1);
    num1++
}

console.log("THE END !!");