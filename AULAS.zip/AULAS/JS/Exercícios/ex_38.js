let senha ="palmeiras100mundial"

 if (senha == "" || senha == " ") {
    console.log("Erro");
 }
 
 else if (senha == "Palmeiras100mundial") {
        console.log("Senha correta");
    }
    else {
        console.log("Senha incorreta");
    } 
 



// Escreva um programa que peça ao usuário uma senha e verifique se ela é válida. Considere uma senha válida aquela que tem pelo menos 8 caracteres. Em seguida, imprima na tela uma mensagem indicando o resultado.