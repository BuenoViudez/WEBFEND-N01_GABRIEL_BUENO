let numero = []

let i = 0

while (i <= 30) {
    if (i % 3 === 0) {
        numero.push(i);
    }
    i++
}

console.log(numero);