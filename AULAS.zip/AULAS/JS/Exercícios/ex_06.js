let base = 7
let altura = 3
let soma = base*altura

console.log(soma)

console.log(`A parede da sala do Bluen Pen tem ${base}M x ${altura}M, com isso ele vai precisar comprar ${soma} metros quadrados de papel de parede `)
