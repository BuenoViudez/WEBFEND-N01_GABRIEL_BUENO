let base = 17
let altura1 = 17
let altura2 = 17
let soma = base + altura1 + altura2

console.log(soma)

console.log(` Sabendo que cada medida corresponde a ${base}M concluísse que o perímetro é ${soma} Metros `)