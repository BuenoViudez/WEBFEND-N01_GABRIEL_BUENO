let posição = 1; 
let Seleção = "";
let podio = "";

switch (posição) {
    case 1:
        Seleção = "Argentina";
        podio = "1º Luga";
        break;
    case 2:
        Seleção = "França";
        podio = "2º Lugar";
        break;
    case 3:
        Seleção = "Croacia";
        podio = "3º Lugar";
        break;
  
}
console.log(Seleção + "\n" + podio);