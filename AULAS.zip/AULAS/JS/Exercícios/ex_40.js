let Celcius = 0;
let Fahrenheit = 0;
