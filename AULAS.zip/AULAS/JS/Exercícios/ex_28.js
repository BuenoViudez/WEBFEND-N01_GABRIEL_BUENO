let num1 = 9
let num2 = 0
let soma = num1 + num2
console.log(soma)


if (soma > 10) {
    console.log(`A somatoria de ${num1} + ${num2} é igual a ${soma} `)
}
else {
    console.log(`A somatoria de ${num1} + ${num2} nao é igual a ${soma} `)
}