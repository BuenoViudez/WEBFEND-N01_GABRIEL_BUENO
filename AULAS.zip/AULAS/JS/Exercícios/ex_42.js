let diaSemana = 7;
let mensagem = "";

switch (diaSemana) {
    case 1:
        mensagem = "Fim de semana";
        break;
    case 2:
        mensagem = "Dia útil";
        break;
    case 3:
        mensagem = "Dia útil";
        break;
    case 4:
        mensagem = "Dia útil";
        break;
    case 5:
        mensagem = "Dia útil";
        break;
    case 6:
        mensagem = "Dia útil";
        break;
    case 7:
        mensagem = "Sábado";
        break;
    default:
        mensagem = "Fim de semana";
        break;
}

console.log(mensagem);