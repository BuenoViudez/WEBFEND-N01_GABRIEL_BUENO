let soma = 0;
for(let i = 0; i <= 100; i++ ) {
        soma += i  

}
console.log(soma);   




