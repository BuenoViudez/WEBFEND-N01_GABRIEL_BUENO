let base = 13
let altura = 7
let area = base * altura / 2


console.log(`A area de um triangulo é de ${area}`)



