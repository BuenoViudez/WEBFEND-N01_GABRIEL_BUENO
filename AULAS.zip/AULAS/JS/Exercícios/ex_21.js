let idade = 17;

if (idade >= 18) {
    console.log(`Você tem ${idade} anos, idade permitida para dirigir`);
}
else {
    console.log("Você não tem idade para dirigir");
 }
