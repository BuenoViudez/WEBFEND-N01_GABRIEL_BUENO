let comprimeto = 5
let largura = 3
let altura = 2
let soma = comprimeto * largura * altura

console.log(soma)

console.log(`O volume total da caixa do Manoel Gomes é a multiplicação de comprimento x largura x altura que corresponde a ${soma} `)