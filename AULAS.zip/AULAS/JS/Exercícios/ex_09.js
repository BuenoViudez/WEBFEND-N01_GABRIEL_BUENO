let catetoA = 6
let catetoB = 8
let hipotenusa = Math.sqrt(100)


let soma = Math.pow(6,2) + Math.pow(8,2)   

console.log(soma)

console.log(`Sabendo os valores dos catetos, concluisse que o valor da Hipotenusa é ${hipotenusa}`)

