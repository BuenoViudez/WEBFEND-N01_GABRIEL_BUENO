let altura = 1.3
let idade = 11

 if (altura >= 1.5 || idade >= 12) {
    console.log(`Manoel Gomes tem altura de ${altura} cm e tem ${idade} anos de idade, pode ir na montanha russa `);
}
else {
    console.log(`Chiquinha tem altura de ${altura} cm e tem ${idade} anos de idade, e não pode ir na motanha russa`);
}







// Escreva um programa que peça ao usuário sua idade e sua altura, e verifique se ele é elegível para andar em um brinquedo de parque de diversões que requer altura mínima de 1,5 metros e idade mínima de 12 anos. Imprima na tela uma mensagem indicando o resultado.