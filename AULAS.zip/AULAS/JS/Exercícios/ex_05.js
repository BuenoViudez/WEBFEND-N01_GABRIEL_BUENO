let area = 5
let lado = 5
let soma = area * lado

console.log(soma)

console.log(`O quarto de Manoel Gomes tem um total de ${soma} metros quadrados`)


