let preço = 1000
let desconto = 25/100 

let  valorDesconto = preço * desconto

let valorComDesconto = preço - valorDesconto

console.log(valorComDesconto)


console.log(`O valor de desconto foi de 25% (R$${valorDesconto.toFixed(2)}), com isso ele vai pagar no final R$${valorComDesconto.toFixed(2)}`)






