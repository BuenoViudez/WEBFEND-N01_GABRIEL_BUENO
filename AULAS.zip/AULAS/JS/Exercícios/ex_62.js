let numero = [];
let i = 0;

while (i <= 20) {
    if (i % 2 === 0) {
    numero.push(i)
    }
    i++
}
console.log(numero);