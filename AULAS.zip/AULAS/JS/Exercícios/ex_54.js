let num100 = 0
let soma = 0


while (num100 <= 100){
    soma += num100;
    // console.log(soma);
    num100++
}
console.log(soma);
console.log("THE END !!");
