let numeros = [100, 10, 100, 10, 100, 10];
let soma = 0


for (let i = 0; i < numeros.length; i++) {
    soma = soma + numeros[i]
}

console.log(soma);


//Calcular a soma dos elementos de um array: