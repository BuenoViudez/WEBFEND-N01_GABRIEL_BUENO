let num1 = 10
let num2 = 20


console.log(num1 * num2);


