let raio = 12
const pi = Math.PI

let circunferencia = raio * 2 * pi   

console.log(circunferencia.toFixed(2))


