let numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

let i = 0

while (i < numeros.length){
    console.log(numeros[i]);
    i++
}

