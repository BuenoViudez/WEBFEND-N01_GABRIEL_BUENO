let num1 = 100
let porcento = 55/100
let porcentagem = num1*porcento

console.log(porcentagem)

console.log(`O faturamento bruto da loja do Manoel Gomes é ${num1} porem o seu lucro liquido é de ${porcentagem}% por mês `)
