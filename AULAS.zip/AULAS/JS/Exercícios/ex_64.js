let nomes = ["Grauco", "Greyce", "Grória"];
let nomi = "";
let i = 0;

while (i < nomes.length) {
    nomi += nomes[i] + ";\n";
    i++;
}

console.log(nomi);