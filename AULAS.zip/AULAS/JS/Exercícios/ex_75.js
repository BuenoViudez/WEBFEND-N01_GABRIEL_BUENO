let taboada = 7
for(let i = 0; i <= 10; i++ ) {
    
    console.log(`${taboada} x ${i} = ${taboada * i}`);

}