for(let i = 0; i <= 50; i++) 

    if (i % 2 === 0) {

        console.log(`${i} É par`);

    }





// Escreva um programa que exiba os números pares de 0 a 50 no console