let list = [1, 54, 5, 1910, 4];
let big = [];

for (let i = 0; i< list.length; i++ ){
    if (list [i] > big)
    big = list [i];

}

console.log(big);



//Encontrar o maior número em uma lista: