// let n = Math.floor(Math.random() [])
// let p = 0;


// while ( n != 0) {
//     if (n % 2 == 0){
//         console.log(`o ${n} é um número Par`);
//         p++       
//     } 
//     n = Math.floor(Math.random() * 22);
// }

// console.log(`Pares = ${p}`);


// console.log("THE END !!");