let pizzas = ["Frango com Catupiry", "4 Queijos", "Calabresa", "Atum"]


for(let i = pizzas.length - 1; i >= 0; i--) {
    console.log(pizzas[i]);


}


//Inverter a ordem de uma string