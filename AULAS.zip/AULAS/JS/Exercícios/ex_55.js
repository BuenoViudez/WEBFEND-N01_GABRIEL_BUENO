let num1 = 10;

while (num1 >=1) {
    console.log(num1);
    num1--
}

console.log("THE END !!!");
