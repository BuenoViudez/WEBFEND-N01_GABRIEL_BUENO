let aniversario = 22;

if (aniversario % 2 == 0) {
    console.log(`Você nasceu no dia ${aniversario}, que é par`);
}
else {
    console.log(`Ou Você nasceu no dia ${aniversario} que é impar`);
 }