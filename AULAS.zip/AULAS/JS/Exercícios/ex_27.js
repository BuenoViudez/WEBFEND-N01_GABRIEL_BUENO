 let nomi = "ManoelGomes" 

 if (nomi == "Maria"){
    console.log(`Seu nome é ${nomi} igual a sua avo que se chamava ${nomi}`);
 }
 else {
    console.log(`Seu nome e ${nomi}, não igual a Maria`);
 }