let tabo1 = 1
let multi = 0


while (multi <= 10){
    console.log(`${tabo1} x ${multi} = ${tabo1 * multi}  `);
    multi++
}


console.log("THE END !!");
