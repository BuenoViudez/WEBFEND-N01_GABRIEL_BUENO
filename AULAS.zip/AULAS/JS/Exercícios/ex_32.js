let num1 = 24
let num2 = 24                                           


if (num1 === num2){
    console.log (`O numero ${num1} é igual ao número ${num2}`)
}
else{
    console.log(`O número ${num1} é diferente do número ${num2}`)
    
}

