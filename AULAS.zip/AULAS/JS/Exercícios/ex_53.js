let num1 = 0;

while (num1 <= 30){
    if (num1 % 3 == 0){
        console.log(`${num1} É multiplo de 3`); 
    }
    num1++    
}

console.log("THE END !!! ");