//Crie uma função que receba uma string como parâmetro e retorne o número de caracteres dessa string.

let palavra = (prompt("Digite uma palvra"));

function contarCaracteres (string){
    return string.length;
}

console.log(contarCaracteres(palavra));
alert(contarCaracteres(palavra));