let numero = [];
let i = 0;

while (i <= 10) {
    if (i != 0) {
    numero.push(i)
    }
    i++
}
console.log(numero);