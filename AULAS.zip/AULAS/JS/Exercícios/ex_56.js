let num1 = 1
let mult = 1


while (num1 <= 5){
    mult *= num1;
    console.log(mult);
    num1++
}
console.log("THE END !!");
