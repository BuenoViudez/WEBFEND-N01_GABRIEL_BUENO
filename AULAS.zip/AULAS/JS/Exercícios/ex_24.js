let numero = 1

 if (numero > 0) {
    console.log(`o número ${numero} é positivo`);
}

else if (numero < 0) {
    console.log(`o número ${numero} é negativo`);
}
else {
    console.log(`o número é ${numero}`);
}