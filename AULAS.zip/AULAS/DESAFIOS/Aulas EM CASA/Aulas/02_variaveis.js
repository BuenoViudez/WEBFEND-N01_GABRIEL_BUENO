let nome = "Gabriel";
let sobrenome = "Bueno";
const idade = 26;
let nomeCompleto = nome + " " + sobrenome;

console.log("olá, meu nome é " + nomeCompleto + " e tenho " + idade + " nos de idade")

nome = "Manoel"
sobrenome = "Gomes"
nomeCompleto = nome + " " + sobrenome;

console.log(`Olá, meu nome é  ${nomeCompleto} e tenho ${idade} anos de idade`)

let n1 = 8;
let n2 = 3;
let n3 = "1";
let n4 = "3";


console.log(n1 + n2)
console.log(n2 + n3)
console.log(n1 + n3)


console.log(n1 == n2)
console.log(n1 != n2)
console.log(n1 === n2)
console.log(n1 !== n2)
console.log(n1 == n4)
console.log(n1 === n4)
console.log(n1 > n2)
console.log(n1 < n2)
