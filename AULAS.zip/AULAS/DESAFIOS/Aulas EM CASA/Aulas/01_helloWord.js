let primeiroCodigo = "Hello Word"

console.log(primeiroCodigo)
