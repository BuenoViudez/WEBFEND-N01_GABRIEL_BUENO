let numeros = [23, 7, 5, 14, 30, 22, 65]

console.log(numeros [4], numeros[5]);
console.log("Comprimento de " + numeros.length);
// numeros [3] = 25

let i = 0;
let soma = 0;

while (i < numeros.length) {
    console.log(numeros[i]);
    soma = soma + numeros[i]
    i++
}