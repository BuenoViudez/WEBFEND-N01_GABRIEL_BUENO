for (let i = 0; i <= 10; i++){
    console.log(i);
}

let animes = ["Digimon", "Naruto", "Power Rangers", "Chaves"]

for(let i = 0; i < animes.length; i++) {
    console.log(animes[i]);
}

console.log(animes.includes("X-MEN"));

for(let i = animes.length - 1; i >= 0; i--) {
    console.log(animes[i]);

}