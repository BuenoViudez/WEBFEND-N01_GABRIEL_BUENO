let num1 = 49;
let num2 = 90;

console.log(num1 + num2)

let soma = num1 + num2

console.log(soma)

let sub = num1 - num2

console.log(sub)

let divi = num1 / num2

console.log(divi)

let multi = num1 * num2

console.log(multi)

console.log(n1 + n2)
console.log(n2 + n3)
console.log(n1 + n3)


console.log(n1 == n2)
console.log(n1 != n2)
console.log(n1 === n2)
console.log(n1 !== n2)
console.log(n1 == n4)
console.log(n1 === n4)
console.log(n1 > n2)
console.log(n1 < n2)

