let idade = 17;

if (idade >= 18) {
    console.log("Você tem idade para dirigir");
}
else {
    console.log("Você não tem idade para dirigir");
 }

 let numero = 0 

 if (numero > 0) {
    console.log(`o número ${numero}`);
}

else if (numero < 0) {
    console.log(`o número ${numero} é negativo`);
}
else {
    
    console.log(`o número é ${numero}`);

 }

 let senha ="Senai123"

 if (senha == "" || senha == " ") {
    console.log("Erro");
 }
 else {
    if (senha != "Senai123" && senha != "SENAI123" && senha != "senai123") {
        console.log("Senha incorreta");
    }
    else {
        console.log("Senha correta");
    }
 }

 let senha1 = "Gabriel"
 let senha2 = "Gabriel"

 if (senha == senha2){
    console.log("As senhas são iguais"); 
 }
else {
    console.log("As senhas estão diferentes");
}

    // ** EXEMPLO **

    // let n 
    // if (n % 2 !=0)
    // n%3==0

     